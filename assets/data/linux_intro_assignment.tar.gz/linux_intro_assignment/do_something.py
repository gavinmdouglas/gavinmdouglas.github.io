#!/usr/bin/python3

import sys

# Commands to print to standard output.
print("ID241	0	20	11")
print("ID1	99	42	2811")
print("ID54	28	58	2")
print("ID42	51	59	0")

# Commands to print to standard error.
print("This is your helpful standard error output!", file=sys.stderr)
print("This output could include errors, warnings, or just useful extra information", file=sys.stderr)

